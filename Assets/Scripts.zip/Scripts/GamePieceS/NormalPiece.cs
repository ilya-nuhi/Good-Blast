using UnityEngine;

public class NormalPiece : GamePiece
{
    public override void Initialize()
    {
        
    }
}
